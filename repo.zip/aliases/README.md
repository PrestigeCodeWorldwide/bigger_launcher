#Supported Aliases:
/nt -> /nav target