-- Adds NoS zones again
return {
	[1] = {
		[1] = 1,
		[2] = 'South Qeynos',
		[3] = 'qeynos',
	},
	[2] = {
		[1] = 2,
		[2] = 'North Qeynos',
		[3] = 'qeynos2',
	},
	[3] = {
		[1] = 3,
		[2] = 'Surefall Glade',
		[3] = 'qrg',
	},
	[4] = {
		[1] = 4,
		[2] = 'Qeynos Hills',
		[3] = 'qeytoqrg',
	},
	[5] = {
		[1] = 6,
		[2] = 'High Keep',
		[3] = 'highkeep',
	},
	[6] = {
		[1] = 8,
		[2] = 'North Freeport',
		[3] = 'freportn',
	},
	[7] = {
		[1] = 9,
		[2] = 'West Freeport',
		[3] = 'freportw',
	},
	[8] = {
		[1] = 10,
		[2] = 'East Freeport',
		[3] = 'freporte',
	},
	[9] = {
		[1] = 11,
		[2] = 'The Liberated Citadel of Runnyeye',
		[3] = 'runnyeye',
	},
	[10] = {
		[1] = 12,
		[2] = 'The Western Plains of Karana',
		[3] = 'qey2hh1',
	},
	[11] = {
		[1] = 13,
		[2] = 'The Northern Plains of Karana',
		[3] = 'northkarana',
	},
	[12] = {
		[1] = 14,
		[2] = 'The Southern Plains of Karana',
		[3] = 'southkarana',
	},
	[13] = {
		[1] = 15,
		[2] = 'The Eastern Plains of Karana',
		[3] = 'eastkarana',
	},
	[14] = {
		[1] = 16,
		[2] = 'The Gorge of King Xorbb',
		[3] = 'beholder',
	},
	[15] = {
		[1] = 17,
		[2] = 'Blackburrow',
		[3] = 'blackburrow',
	},
	[16] = {
		[1] = 18,
		[2] = 'The Lair of the Splitpaw',
		[3] = 'paw',
	},
	[17] = {
		[1] = 19,
		[2] = 'Rivervale',
		[3] = 'rivervale',
	},
	[18] = {
		[1] = 20,
		[2] = 'Kithicor Forest',
		[3] = 'kithicor',
	},
	[19] = {
		[1] = 21,
		[2] = 'West Commonlands',
		[3] = 'commons',
	},
	[20] = {
		[1] = 22,
		[2] = 'East Commonlands',
		[3] = 'ecommons',
	},
	[21] = {
		[1] = 23,
		[2] = 'Erudin Palace',
		[3] = 'erudnint',
	},
	[22] = {
		[1] = 24,
		[2] = 'Erudin',
		[3] = 'erudnext',
	},
	[23] = {
		[1] = 25,
		[2] = 'Nektulos Forest',
		[3] = 'nektulos',
	},
	[24] = {
		[1] = 26,
		[2] = 'Sunset Home',
		[3] = 'cshome',
	},
	[25] = {
		[1] = 27,
		[2] = 'The Lavastorm Mountains',
		[3] = 'lavastorm',
	},
	[26] = {
		[1] = 29,
		[2] = 'Halas',
		[3] = 'halas',
	},
	[27] = {
		[1] = 30,
		[2] = 'Everfrost Peaks',
		[3] = 'everfrost',
	},
	[28] = {
		[1] = 31,
		[2] = 'Solusek\'s Eye',
		[3] = 'soldunga',
	},
	[29] = {
		[1] = 32,
		[2] = 'Nagafen\'s Lair',
		[3] = 'soldungb',
	},
	[30] = {
		[1] = 34,
		[2] = 'The Northern Desert of Ro',
		[3] = 'nro',
	},
	[31] = {
		[1] = 35,
		[2] = 'The Southern Desert of Ro',
		[3] = 'sro',
	},
	[32] = {
		[1] = 36,
		[2] = 'Befallen',
		[3] = 'befallen',
	},
	[33] = {
		[1] = 37,
		[2] = 'The Oasis of Marr',
		[3] = 'oasis',
	},
	[34] = {
		[1] = 39,
		[2] = 'The Ruins of Old Paineel',
		[3] = 'hole',
	},
	[35] = {
		[1] = 40,
		[2] = 'Neriak - Foreign Quarter',
		[3] = 'neriaka',
	},
	[36] = {
		[1] = 41,
		[2] = 'Neriak - Commons',
		[3] = 'neriakb',
	},
	[37] = {
		[1] = 42,
		[2] = 'Neriak - Third Gate',
		[3] = 'neriakc',
	},
	[38] = {
		[1] = 43,
		[2] = 'Neriak - Fourth Gate',
		[3] = 'neriakd',
	},
	[39] = {
		[1] = 44,
		[2] = 'Najena',
		[3] = 'najena',
	},
	[40] = {
		[1] = 45,
		[2] = 'The Qeynos Aqueduct System',
		[3] = 'qcat',
	},
	[41] = {
		[1] = 47,
		[2] = 'The Feerrott',
		[3] = 'feerrott',
	},
	[42] = {
		[1] = 48,
		[2] = 'Temple of Cazic-Thule',
		[3] = 'cazicthule',
	},
	[43] = {
		[1] = 49,
		[2] = 'Oggok',
		[3] = 'oggok',
	},
	[44] = {
		[1] = 50,
		[2] = 'The Rathe Mountains',
		[3] = 'rathemtn',
	},
	[45] = {
		[1] = 51,
		[2] = 'Lake Rathetear',
		[3] = 'lakerathe',
	},
	[46] = {
		[1] = 52,
		[2] = 'Grobb',
		[3] = 'grobb',
	},
	[47] = {
		[1] = 53,
		[2] = 'Aviak',
		[3] = 'aviak',
	},
	[48] = {
		[1] = 54,
		[2] = 'The Greater Faydark',
		[3] = 'gfaydark',
	},
	[49] = {
		[1] = 55,
		[2] = 'Ak\'Anon',
		[3] = 'akanon',
	},
	[50] = {
		[1] = 57,
		[2] = 'The Lesser Faydark',
		[3] = 'lfaydark',
	},
	[51] = {
		[1] = 58,
		[2] = 'Clan Crushbone',
		[3] = 'crushbone',
	},
	[52] = {
		[1] = 59,
		[2] = 'The Castle of Mistmoore',
		[3] = 'mistmoore',
	},
	[53] = {
		[1] = 60,
		[2] = 'South Kaladim',
		[3] = 'kaladima',
	},
	[54] = {
		[1] = 61,
		[2] = 'Northern Felwithe',
		[3] = 'felwithea',
	},
	[55] = {
		[1] = 62,
		[2] = 'Southern Felwithe',
		[3] = 'felwitheb',
	},
	[56] = {
		[1] = 63,
		[2] = 'The Estate of Unrest',
		[3] = 'unrest',
	},
	[57] = {
		[1] = 64,
		[2] = 'Kedge Keep',
		[3] = 'kedge',
	},
	[58] = {
		[1] = 65,
		[2] = 'The City of Guk',
		[3] = 'guktop',
	},
	[59] = {
		[1] = 66,
		[2] = 'The Ruins of Old Guk',
		[3] = 'gukbottom',
	},
	[60] = {
		[1] = 67,
		[2] = 'North Kaladim',
		[3] = 'kaladimb',
	},
	[61] = {
		[1] = 68,
		[2] = 'Butcherblock Mountains',
		[3] = 'butcher',
	},
	[62] = {
		[1] = 69,
		[2] = 'The Ocean of Tears',
		[3] = 'oot',
	},
	[63] = {
		[1] = 70,
		[2] = 'Dagnor\'s Cauldron',
		[3] = 'cauldron',
	},
	[64] = {
		[1] = 71,
		[2] = 'The Plane of Sky',
		[3] = 'airplane',
	},
	[65] = {
		[1] = 72,
		[2] = 'The Plane of Fear',
		[3] = 'fearplane',
	},
	[66] = {
		[1] = 73,
		[2] = 'Permafrost Keep',
		[3] = 'permafrost',
	},
	[67] = {
		[1] = 75,
		[2] = 'Paineel',
		[3] = 'paineel',
	},
	[68] = {
		[1] = 76,
		[2] = 'The Plane of Hate',
		[3] = 'hateplane',
	},
	[69] = {
		[1] = 77,
		[2] = 'The Arena',
		[3] = 'arena',
	},
	[70] = {
		[1] = 78,
		[2] = 'The Field of Bone',
		[3] = 'fieldofbone',
	},
	[71] = {
		[1] = 79,
		[2] = 'The Warsliks Woods',
		[3] = 'warslikswood',
	},
	[72] = {
		[1] = 80,
		[2] = 'The Temple of Solusek Ro',
		[3] = 'soltemple',
	},
	[73] = {
		[1] = 81,
		[2] = 'The Temple of Droga',
		[3] = 'droga',
	},
	[74] = {
		[1] = 82,
		[2] = 'Cabilis West',
		[3] = 'cabwest',
	},
	[75] = {
		[1] = 83,
		[2] = 'The Swamp of No Hope',
		[3] = 'swampofnohope',
	},
	[76] = {
		[1] = 84,
		[2] = 'Firiona Vie',
		[3] = 'firiona',
	},
	[77] = {
		[1] = 85,
		[2] = 'Lake of Ill Omen',
		[3] = 'lakeofillomen',
	},
	[78] = {
		[1] = 86,
		[2] = 'The Dreadlands',
		[3] = 'dreadlands',
	},
	[79] = {
		[1] = 87,
		[2] = 'The Burning Woods',
		[3] = 'burningwood',
	},
	[80] = {
		[1] = 88,
		[2] = 'Kaesora',
		[3] = 'kaesora',
	},
	[81] = {
		[1] = 89,
		[2] = 'The Ruins of Sebilis',
		[3] = 'sebilis',
	},
	[82] = {
		[1] = 90,
		[2] = 'The City of Mist',
		[3] = 'citymist',
	},
	[83] = {
		[1] = 91,
		[2] = 'The Skyfire Mountains',
		[3] = 'skyfire',
	},
	[84] = {
		[1] = 92,
		[2] = 'Frontier Mountains',
		[3] = 'frontiermtns',
	},
	[85] = {
		[1] = 93,
		[2] = 'The Overthere',
		[3] = 'overthere',
	},
	[86] = {
		[1] = 94,
		[2] = 'The Emerald Jungle',
		[3] = 'emeraldjungle',
	},
	[87] = {
		[1] = 95,
		[2] = 'Trakanon\'s Teeth',
		[3] = 'trakanon',
	},
	[88] = {
		[1] = 96,
		[2] = 'Timorous Deep',
		[3] = 'timorous',
	},
	[89] = {
		[1] = 97,
		[2] = 'Kurn\'s Tower',
		[3] = 'kurn',
	},
	[90] = {
		[1] = 98,
		[2] = 'Erud\'s Crossing',
		[3] = 'erudsxing',
	},
	[91] = {
		[1] = 100,
		[2] = 'The Stonebrunt Mountains',
		[3] = 'stonebrunt',
	},
	[92] = {
		[1] = 101,
		[2] = 'The Warrens',
		[3] = 'warrens',
	},
	[93] = {
		[1] = 102,
		[2] = 'Karnor\'s Castle',
		[3] = 'karnor',
	},
	[94] = {
		[1] = 103,
		[2] = 'Chardok',
		[3] = 'chardok',
	},
	[95] = {
		[1] = 104,
		[2] = 'The Crypt of Dalnir',
		[3] = 'dalnir',
	},
	[96] = {
		[1] = 105,
		[2] = 'Howling Stones',
		[3] = 'charasis',
	},
	[97] = {
		[1] = 106,
		[2] = 'Cabilis East',
		[3] = 'cabeast',
	},
	[98] = {
		[1] = 107,
		[2] = 'The Mines of Nurga',
		[3] = 'nurga',
	},
	[99] = {
		[1] = 108,
		[2] = 'Veeshan\'s Peak',
		[3] = 'veeshan',
	},
	[100] = {
		[1] = 109,
		[2] = 'Veksar',
		[3] = 'veksar',
	},
	[101] = {
		[1] = 110,
		[2] = 'The Iceclad Ocean',
		[3] = 'iceclad',
	},
	[102] = {
		[1] = 111,
		[2] = 'The Tower of Frozen Shadow',
		[3] = 'frozenshadow',
	},
	[103] = {
		[1] = 112,
		[2] = 'Velketor\'s Labyrinth',
		[3] = 'velketor',
	},
	[104] = {
		[1] = 113,
		[2] = 'Kael Drakkel',
		[3] = 'kael',
	},
	[105] = {
		[1] = 114,
		[2] = 'Skyshrine',
		[3] = 'skyshrine',
	},
	[106] = {
		[1] = 115,
		[2] = 'The City of Thurgadin',
		[3] = 'thurgadina',
	},
	[107] = {
		[1] = 116,
		[2] = 'Eastern Wastes',
		[3] = 'eastwastes',
	},
	[108] = {
		[1] = 117,
		[2] = 'Cobalt Scar',
		[3] = 'cobaltscar',
	},
	[109] = {
		[1] = 118,
		[2] = 'The Great Divide',
		[3] = 'greatdivide',
	},
	[110] = {
		[1] = 119,
		[2] = 'The Wakening Land',
		[3] = 'wakening',
	},
	[111] = {
		[1] = 120,
		[2] = 'The Western Wastes',
		[3] = 'westwastes',
	},
	[112] = {
		[1] = 121,
		[2] = 'Crystal Caverns',
		[3] = 'crystal',
	},
	[113] = {
		[1] = 123,
		[2] = 'Dragon Necropolis',
		[3] = 'necropolis',
	},
	[114] = {
		[1] = 124,
		[2] = 'The Temple of Veeshan',
		[3] = 'templeveeshan',
	},
	[115] = {
		[1] = 125,
		[2] = 'Siren\'s Grotto',
		[3] = 'sirens',
	},
	[116] = {
		[1] = 126,
		[2] = 'The Plane of Mischief',
		[3] = 'mischiefplane',
	},
	[117] = {
		[1] = 127,
		[2] = 'The Plane of Growth',
		[3] = 'growthplane',
	},
	[118] = {
		[1] = 128,
		[2] = 'The Sleeper\'s Tomb',
		[3] = 'sleeper',
	},
	[119] = {
		[1] = 129,
		[2] = 'Icewell Keep',
		[3] = 'thurgadinb',
	},
	[120] = {
		[1] = 150,
		[2] = 'Shadow Haven',
		[3] = 'shadowhaven',
	},
	[121] = {
		[1] = 151,
		[2] = 'The Bazaar',
		[3] = 'bazaar',
	},
	[122] = {
		[1] = 152,
		[2] = 'The Nexus',
		[3] = 'nexus',
	},
	[123] = {
		[1] = 153,
		[2] = 'Echo Caverns',
		[3] = 'echo',
	},
	[124] = {
		[1] = 154,
		[2] = 'Acrylia Caverns',
		[3] = 'acrylia',
	},
	[125] = {
		[1] = 155,
		[2] = 'Shar Vahl',
		[3] = 'sharvahl',
	},
	[126] = {
		[1] = 156,
		[2] = 'Paludal Caverns',
		[3] = 'paludal',
	},
	[127] = {
		[1] = 157,
		[2] = 'The Fungus Grove',
		[3] = 'fungusgrove',
	},
	[128] = {
		[1] = 158,
		[2] = 'Vex Thal',
		[3] = 'vexthal',
	},
	[129] = {
		[1] = 159,
		[2] = 'Sanctus Seru',
		[3] = 'sseru',
	},
	[130] = {
		[1] = 160,
		[2] = 'Katta Castellum',
		[3] = 'katta',
	},
	[131] = {
		[1] = 161,
		[2] = 'Netherbian Lair',
		[3] = 'netherbian',
	},
	[132] = {
		[1] = 162,
		[2] = 'Ssraeshza Temple',
		[3] = 'ssratemple',
	},
	[133] = {
		[1] = 163,
		[2] = 'Grieg\'s End',
		[3] = 'griegsend',
	},
	[134] = {
		[1] = 164,
		[2] = 'The Deep',
		[3] = 'thedeep',
	},
	[135] = {
		[1] = 165,
		[2] = 'Shadeweaver\'s Thicket',
		[3] = 'shadeweaver',
	},
	[136] = {
		[1] = 166,
		[2] = 'Hollowshade Moor',
		[3] = 'hollowshade',
	},
	[137] = {
		[1] = 167,
		[2] = 'Grimling Forest',
		[3] = 'grimling',
	},
	[138] = {
		[1] = 168,
		[2] = 'Marus Seru',
		[3] = 'mseru',
	},
	[139] = {
		[1] = 169,
		[2] = 'Mons Letalis',
		[3] = 'letalis',
	},
	[140] = {
		[1] = 170,
		[2] = 'The Twilight Sea',
		[3] = 'twilight',
	},
	[141] = {
		[1] = 171,
		[2] = 'The Grey',
		[3] = 'thegrey',
	},
	[142] = {
		[1] = 172,
		[2] = 'The Tenebrous Mountains',
		[3] = 'tenebrous',
	},
	[143] = {
		[1] = 173,
		[2] = 'The Maiden\'s Eye',
		[3] = 'maiden',
	},
	[144] = {
		[1] = 174,
		[2] = 'Dawnshroud Peaks',
		[3] = 'dawnshroud',
	},
	[145] = {
		[1] = 175,
		[2] = 'The Scarlet Desert',
		[3] = 'scarlet',
	},
	[146] = {
		[1] = 176,
		[2] = 'The Umbral Plains',
		[3] = 'umbral',
	},
	[147] = {
		[1] = 179,
		[2] = 'The Akheva Ruins',
		[3] = 'akheva',
	},
	[148] = {
		[1] = 181,
		[2] = 'Jaggedpine Forest',
		[3] = 'jaggedpine',
	},
	[149] = {
		[1] = 182,
		[2] = 'Nedaria\'s Landing',
		[3] = 'nedaria',
	},
	[150] = {
		[1] = 186,
		[2] = 'The Plane of Hate',
		[3] = 'hateplaneb',
	},
	[151] = {
		[1] = 187,
		[2] = 'Shadowrest',
		[3] = 'shadowrest',
	},
	[152] = {
		[1] = 188,
		[2] = 'The Mines of Gloomingdeep',
		[3] = 'tutoriala',
	},
	[153] = {
		[1] = 189,
		[2] = 'The Mines of Gloomingdeep',
		[3] = 'tutorialb',
	},
	[154] = {
		[1] = 200,
		[2] = 'Ruins of Lxanvom',
		[3] = 'codecay',
	},
	[155] = {
		[1] = 201,
		[2] = 'The Plane of Justice',
		[3] = 'pojustice',
	},
	[156] = {
		[1] = 202,
		[2] = 'The Plane of Knowledge',
		[3] = 'poknowledge',
	},
	[157] = {
		[1] = 203,
		[2] = 'The Plane of Tranquility',
		[3] = 'potranquility',
	},
	[158] = {
		[1] = 204,
		[2] = 'The Plane of Nightmare',
		[3] = 'ponightmare',
	},
	[159] = {
		[1] = 205,
		[2] = 'The Plane of Disease',
		[3] = 'podisease',
	},
	[160] = {
		[1] = 206,
		[2] = 'The Plane of Innovation',
		[3] = 'poinnovation',
	},
	[161] = {
		[1] = 207,
		[2] = 'Torment, the Plane of Pain',
		[3] = 'potorment',
	},
	[162] = {
		[1] = 208,
		[2] = 'The Plane of Valor',
		[3] = 'povalor',
	},
	[163] = {
		[1] = 209,
		[2] = 'Torden, the Bastion of Thunder',
		[3] = 'bothunder',
	},
	[164] = {
		[1] = 210,
		[2] = 'The Plane of Storms',
		[3] = 'postorms',
	},
	[165] = {
		[1] = 211,
		[2] = 'The Halls of Honor',
		[3] = 'hohonora',
	},
	[166] = {
		[1] = 212,
		[2] = 'The Tower of Solusek Ro',
		[3] = 'solrotower',
	},
	[167] = {
		[1] = 213,
		[2] = 'The Plane of War',
		[3] = 'powar',
	},
	[168] = {
		[1] = 214,
		[2] = 'Drunder, the Fortress of Zek',
		[3] = 'potactics',
	},
	[169] = {
		[1] = 215,
		[2] = 'Eryslai, the Kingdom of Wind',
		[3] = 'poair',
	},
	[170] = {
		[1] = 216,
		[2] = 'The Reef of Coirnav',
		[3] = 'powater',
	},
	[171] = {
		[1] = 217,
		[2] = 'Doomfire, the Burning Lands',
		[3] = 'pofire',
	},
	[172] = {
		[1] = 218,
		[2] = 'Vegarlson, The Earthen Badlands',
		[3] = 'poeartha',
	},
	[173] = {
		[1] = 219,
		[2] = 'The Plane of Time',
		[3] = 'potimea',
	},
	[174] = {
		[1] = 220,
		[2] = 'The Temple of Marr',
		[3] = 'hohonorb',
	},
	[175] = {
		[1] = 221,
		[2] = 'The Lair of Terris-Thule',
		[3] = 'nightmareb',
	},
	[176] = {
		[1] = 222,
		[2] = 'Ragrax, Stronghold of the Twelve',
		[3] = 'poearthb',
	},
	[177] = {
		[1] = 223,
		[2] = 'The Prison of the Forsaken',
		[3] = 'potimeb',
	},
	[178] = {
		[1] = 224,
		[2] = 'The Gulf of Gunthak',
		[3] = 'gunthak',
	},
	[179] = {
		[1] = 225,
		[2] = 'Dulak\'s Harbor',
		[3] = 'dulak',
	},
	[180] = {
		[1] = 226,
		[2] = 'The Torgiran Mines',
		[3] = 'torgiran',
	},
	[181] = {
		[1] = 227,
		[2] = 'The Crypt of Nadox',
		[3] = 'nadox',
	},
	[182] = {
		[1] = 228,
		[2] = 'Hate\'s Fury',
		[3] = 'hatesfury',
	},
	[183] = {
		[1] = 229,
		[2] = 'Deepest Guk: Cauldron of Lost Souls',
		[3] = 'guka',
	},
	[184] = {
		[1] = 230,
		[2] = 'The Rujarkian Hills: Bloodied Quarries',
		[3] = 'ruja',
	},
	[185] = {
		[1] = 231,
		[2] = 'Takish-Hiz: Sunken Library',
		[3] = 'taka',
	},
	[186] = {
		[1] = 232,
		[2] = 'Miragul\'s Menagerie: Silent Gallery',
		[3] = 'mira',
	},
	[187] = {
		[1] = 233,
		[2] = 'Mistmoore\'s Catacombs: Forlorn Caverns',
		[3] = 'mmca',
	},
	[188] = {
		[1] = 234,
		[2] = 'Deepest Guk: Drowning Crypt',
		[3] = 'gukb',
	},
	[189] = {
		[1] = 235,
		[2] = 'The Rujarkian Hills: Halls of War',
		[3] = 'rujb',
	},
	[190] = {
		[1] = 236,
		[2] = 'Takish-Hiz: Shifting Tower',
		[3] = 'takb',
	},
	[191] = {
		[1] = 237,
		[2] = 'Miragul\'s Menagerie: Maw of the Menagerie',
		[3] = 'mirb',
	},
	[192] = {
		[1] = 238,
		[2] = 'Mistmoore\'s Catacombs: Dreary Grotto',
		[3] = 'mmcb',
	},
	[193] = {
		[1] = 239,
		[2] = 'Deepest Guk: Ancient Aqueducts',
		[3] = 'gukc',
	},
	[194] = {
		[1] = 240,
		[2] = 'The Rujarkian Hills: Wind Bridges',
		[3] = 'rujc',
	},
	[195] = {
		[1] = 241,
		[2] = 'Takish-Hiz: Fading Temple',
		[3] = 'takc',
	},
	[196] = {
		[1] = 242,
		[2] = 'Miragul\'s Menagerie: Spider Den',
		[3] = 'mirc',
	},
	[197] = {
		[1] = 243,
		[2] = 'Mistmoore\'s Catacombs: Asylum of Invoked Stone',
		[3] = 'mmcc',
	},
	[198] = {
		[1] = 244,
		[2] = 'Deepest Guk: Mushroom Grove',
		[3] = 'gukd',
	},
	[199] = {
		[1] = 245,
		[2] = 'The Rujarkian Hills: Gladiator Pits',
		[3] = 'rujd',
	},
	[200] = {
		[1] = 246,
		[2] = 'Takish-Hiz: Royal Observatory',
		[3] = 'takd',
	},
	[201] = {
		[1] = 247,
		[2] = 'Miragul\'s Menagerie: Hushed Banquet',
		[3] = 'mird',
	},
	[202] = {
		[1] = 248,
		[2] = 'Mistmoore\'s Catacombs: Chambers of Eternal Affliction',
		[3] = 'mmcd',
	},
	[203] = {
		[1] = 249,
		[2] = 'Deepest Guk: Foreboding Prison',
		[3] = 'guke',
	},
	[204] = {
		[1] = 250,
		[2] = 'The Rujarkian Hills: Drudge Hollows',
		[3] = 'ruje',
	},
	[205] = {
		[1] = 251,
		[2] = 'Takish-Hiz: River of Recollection',
		[3] = 'take',
	},
	[206] = {
		[1] = 252,
		[2] = 'Miragul\'s Menagerie: Frosted Halls',
		[3] = 'mire',
	},
	[207] = {
		[1] = 253,
		[2] = 'Mistmoore\'s Catacombs: Sepulcher of the Damned',
		[3] = 'mmce',
	},
	[208] = {
		[1] = 254,
		[2] = 'Deepest Guk: Chapel of the Witnesses',
		[3] = 'gukf',
	},
	[209] = {
		[1] = 255,
		[2] = 'The Rujarkian Hills: Fortified Lair of the Taskmasters',
		[3] = 'rujf',
	},
	[210] = {
		[1] = 256,
		[2] = 'Takish-Hiz: Sandfall Corridors',
		[3] = 'takf',
	},
	[211] = {
		[1] = 257,
		[2] = 'Miragul\'s Menagerie: Forgotten Wastes',
		[3] = 'mirf',
	},
	[212] = {
		[1] = 258,
		[2] = 'Mistmoore\'s Catacombs: Ritualistic Summoning Grounds',
		[3] = 'mmcf',
	},
	[213] = {
		[1] = 259,
		[2] = 'Deepest Guk: Root Garden',
		[3] = 'gukg',
	},
	[214] = {
		[1] = 260,
		[2] = 'The Rujarkian Hills: Hidden Vale',
		[3] = 'rujg',
	},
	[215] = {
		[1] = 261,
		[2] = 'Takish-Hiz: Balancing Chamber',
		[3] = 'takg',
	},
	[216] = {
		[1] = 262,
		[2] = 'Miragul\'s Menagerie: Heart of the Menagerie',
		[3] = 'mirg',
	},
	[217] = {
		[1] = 263,
		[2] = 'Mistmoore\'s Catacombs: Cesspits of Putrescence',
		[3] = 'mmcg',
	},
	[218] = {
		[1] = 264,
		[2] = 'Deepest Guk: Accursed Sanctuary',
		[3] = 'gukh',
	},
	[219] = {
		[1] = 265,
		[2] = 'The Rujarkian Hills: Blazing Forge ',
		[3] = 'rujh',
	},
	[220] = {
		[1] = 266,
		[2] = 'Takish-Hiz: Sweeping Tides',
		[3] = 'takh',
	},
	[221] = {
		[1] = 267,
		[2] = 'Miragul\'s Menagerie: Morbid Laboratory',
		[3] = 'mirh',
	},
	[222] = {
		[1] = 268,
		[2] = 'Mistmoore\'s Catacombs: Aisles of Blood',
		[3] = 'mmch',
	},
	[223] = {
		[1] = 269,
		[2] = 'The Rujarkian Hills: Arena of Chance',
		[3] = 'ruji',
	},
	[224] = {
		[1] = 270,
		[2] = 'Takish-Hiz: Antiquated Palace',
		[3] = 'taki',
	},
	[225] = {
		[1] = 271,
		[2] = 'Miragul\'s Menagerie: Theater of Imprisoned Horrors',
		[3] = 'miri',
	},
	[226] = {
		[1] = 272,
		[2] = 'Mistmoore\'s Catacombs: Halls of Sanguinary Rites',
		[3] = 'mmci',
	},
	[227] = {
		[1] = 273,
		[2] = 'The Rujarkian Hills: Barracks of War',
		[3] = 'rujj',
	},
	[228] = {
		[1] = 274,
		[2] = 'Takish-Hiz: Prismatic Corridors',
		[3] = 'takj',
	},
	[229] = {
		[1] = 275,
		[2] = 'Miragul\'s Menagerie: Grand Library',
		[3] = 'mirj',
	},
	[230] = {
		[1] = 276,
		[2] = 'Mistmoore\'s Catacombs: Infernal Sanctuary',
		[3] = 'mmcj',
	},
	[231] = {
		[1] = 277,
		[2] = 'Chardok: The Halls of Betrayal',
		[3] = 'chardokb',
	},
	[232] = {
		[1] = 278,
		[2] = 'The Caverns of Exile',
		[3] = 'soldungc',
	},
	[233] = {
		[1] = 279,
		[2] = 'The Abysmal Sea',
		[3] = 'abysmal',
	},
	[234] = {
		[1] = 280,
		[2] = 'Natimbi, the Broken Shores',
		[3] = 'natimbi',
	},
	[235] = {
		[1] = 281,
		[2] = 'Qinimi, Court of Nihilia',
		[3] = 'qinimi',
	},
	[236] = {
		[1] = 282,
		[2] = 'Riwwi, Coliseum of Games',
		[3] = 'riwwi',
	},
	[237] = {
		[1] = 283,
		[2] = 'Barindu, Hanging Gardens',
		[3] = 'barindu',
	},
	[238] = {
		[1] = 284,
		[2] = 'Ferubi, Forgotten Temple of Taelosia',
		[3] = 'ferubi',
	},
	[239] = {
		[1] = 285,
		[2] = 'Sewers of Nihilia, Pool of Sludge',
		[3] = 'snpool',
	},
	[240] = {
		[1] = 286,
		[2] = 'Sewers of Nihilia, Lair of Trapped Ones',
		[3] = 'snlair',
	},
	[241] = {
		[1] = 287,
		[2] = 'Sewers of Nihilia, Purifying Plant',
		[3] = 'snplant',
	},
	[242] = {
		[1] = 288,
		[2] = 'Sewers of Nihilia, Emanating Crematory',
		[3] = 'sncrematory',
	},
	[243] = {
		[1] = 289,
		[2] = 'Tipt, Treacherous Crags',
		[3] = 'tipt',
	},
	[244] = {
		[1] = 290,
		[2] = 'Vxed, the Crumbling Caverns',
		[3] = 'vxed',
	},
	[245] = {
		[1] = 291,
		[2] = 'Yxtta, Pulpit of Exiles ',
		[3] = 'yxtta',
	},
	[246] = {
		[1] = 292,
		[2] = 'Uqua, the Ocean God Chantry',
		[3] = 'uqua',
	},
	[247] = {
		[1] = 293,
		[2] = 'Kod\'Taz, Broken Trial Grounds',
		[3] = 'kodtaz',
	},
	[248] = {
		[1] = 294,
		[2] = 'Ikkinz, Chambers of Destruction',
		[3] = 'ikkinz',
	},
	[249] = {
		[1] = 295,
		[2] = 'Qvic, Prayer Grounds of Calling',
		[3] = 'qvic',
	},
	[250] = {
		[1] = 296,
		[2] = 'Inktu\'Ta, the Unmasked Chapel',
		[3] = 'inktuta',
	},
	[251] = {
		[1] = 297,
		[2] = 'Txevu, Lair of the Elite',
		[3] = 'txevu',
	},
	[252] = {
		[1] = 298,
		[2] = 'Tacvi, the Broken Temple',
		[3] = 'tacvi',
	},
	[253] = {
		[1] = 300,
		[2] = 'Wall of Slaughter',
		[3] = 'wallofslaughter',
	},
	[254] = {
		[1] = 301,
		[2] = 'The Bloodfields',
		[3] = 'bloodfields',
	},
	[255] = {
		[1] = 302,
		[2] = 'Dranik\'s Scar',
		[3] = 'draniksscar',
	},
	[256] = {
		[1] = 303,
		[2] = 'Nobles\' Causeway',
		[3] = 'causeway',
	},
	[257] = {
		[1] = 304,
		[2] = 'Proving Grounds',
		[3] = 'chambersa',
	},
	[258] = {
		[1] = 305,
		[2] = 'Proving Grounds',
		[3] = 'chambersb',
	},
	[259] = {
		[1] = 306,
		[2] = 'Proving Grounds',
		[3] = 'chambersc',
	},
	[260] = {
		[1] = 307,
		[2] = 'Proving Grounds',
		[3] = 'chambersd',
	},
	[261] = {
		[1] = 308,
		[2] = 'Proving Grounds',
		[3] = 'chamberse',
	},
	[262] = {
		[1] = 309,
		[2] = 'Proving Grounds',
		[3] = 'chambersf',
	},
	[263] = {
		[1] = 316,
		[2] = 'Muramite Proving Grounds',
		[3] = 'provinggrounds',
	},
	[264] = {
		[1] = 317,
		[2] = 'Anguish, the Fallen Palace',
		[3] = 'anguish',
	},
	[265] = {
		[1] = 318,
		[2] = 'Dranik\'s Hollows: Watering Hole',
		[3] = 'dranikhollowsa',
	},
	[266] = {
		[1] = 319,
		[2] = 'Dranik\'s Hollows: Fire Pit',
		[3] = 'dranikhollowsb',
	},
	[267] = {
		[1] = 320,
		[2] = 'Dranik\'s Hollows: Murkglider Hive',
		[3] = 'dranikhollowsc',
	},
	[268] = {
		[1] = 321,
		[2] = 'Dranik\'s Hollows',
		[3] = 'dranikhollowsd',
	},
	[269] = {
		[1] = 322,
		[2] = 'Dranik\'s Hollows',
		[3] = 'dranikhollowse',
	},
	[270] = {
		[1] = 323,
		[2] = 'Dranik\'s Hollows',
		[3] = 'dranikhollowsf',
	},
	[271] = {
		[1] = 324,
		[2] = 'Dranik\'s Hollows',
		[3] = 'dranikhollowsg',
	},
	[272] = {
		[1] = 325,
		[2] = 'Dranik\'s Hollows',
		[3] = 'dranikhollowsh',
	},
	[273] = {
		[1] = 326,
		[2] = 'Dranik\'s Hollows',
		[3] = 'dranikhollowsi',
	},
	[274] = {
		[1] = 327,
		[2] = 'Dranik\'s Hollows',
		[3] = 'dranikhollowsj',
	},
	[275] = {
		[1] = 328,
		[2] = 'Catacombs of Dranik',
		[3] = 'dranikcatacombsa',
	},
	[276] = {
		[1] = 329,
		[2] = 'Catacombs of Dranik',
		[3] = 'dranikcatacombsb',
	},
	[277] = {
		[1] = 330,
		[2] = 'Catacombs of Dranik',
		[3] = 'dranikcatacombsc',
	},
	[278] = {
		[1] = 331,
		[2] = 'Sewers of Dranik',
		[3] = 'draniksewersa',
	},
	[279] = {
		[1] = 332,
		[2] = 'Sewers of Dranik',
		[3] = 'draniksewersb',
	},
	[280] = {
		[1] = 333,
		[2] = 'Sewers of Dranik',
		[3] = 'draniksewersc',
	},
	[281] = {
		[1] = 334,
		[2] = 'Riftseekers\' Sanctum',
		[3] = 'riftseekers',
	},
	[282] = {
		[1] = 335,
		[2] = 'Harbinger\'s Spire',
		[3] = 'harbingers',
	},
	[283] = {
		[1] = 336,
		[2] = 'The Ruined City of Dranik',
		[3] = 'dranik',
	},
	[284] = {
		[1] = 337,
		[2] = 'The Broodlands',
		[3] = 'broodlands',
	},
	[285] = {
		[1] = 338,
		[2] = 'Stillmoon Temple',
		[3] = 'stillmoona',
	},
	[286] = {
		[1] = 339,
		[2] = 'The Ascent',
		[3] = 'stillmoonb',
	},
	[287] = {
		[1] = 340,
		[2] = 'Thundercrest Isles',
		[3] = 'thundercrest',
	},
	[288] = {
		[1] = 341,
		[2] = 'Lavaspinner\'s Lair',
		[3] = 'delvea',
	},
	[289] = {
		[1] = 342,
		[2] = 'Tirranun\'s Delve',
		[3] = 'delveb',
	},
	[290] = {
		[1] = 343,
		[2] = 'The Accursed Nest',
		[3] = 'thenest',
	},
	[291] = {
		[1] = 344,
		[2] = 'Guild Lobby',
		[3] = 'guildlobby',
	},
	[292] = {
		[1] = 345,
		[2] = 'Guild Hall',
		[3] = 'guildhall',
	},
	[293] = {
		[1] = 347,
		[2] = 'Ruins of Illsalin',
		[3] = 'illsalin',
	},
	[294] = {
		[1] = 348,
		[2] = 'Illsalin Marketplace',
		[3] = 'illsalina',
	},
	[295] = {
		[1] = 349,
		[2] = 'Temple of the Korlach',
		[3] = 'illsalinb',
	},
	[296] = {
		[1] = 350,
		[2] = 'The Nargilor Pits',
		[3] = 'illsalinc',
	},
	[297] = {
		[1] = 351,
		[2] = 'Dreadspire Keep',
		[3] = 'dreadspire',
	},
	[298] = {
		[1] = 354,
		[2] = 'The Hive',
		[3] = 'drachnidhive',
	},
	[299] = {
		[1] = 355,
		[2] = 'The Hatchery',
		[3] = 'drachnidhivea',
	},
	[300] = {
		[1] = 356,
		[2] = 'The Cocoons',
		[3] = 'drachnidhiveb',
	},
	[301] = {
		[1] = 357,
		[2] = 'The Queen\'s Lair',
		[3] = 'drachnidhivec',
	},
	[302] = {
		[1] = 358,
		[2] = 'Stoneroot Falls',
		[3] = 'westkorlach',
	},
	[303] = {
		[1] = 359,
		[2] = 'Chambers of Xill',
		[3] = 'westkorlacha',
	},
	[304] = {
		[1] = 360,
		[2] = 'Caverns of the Lost',
		[3] = 'westkorlachb',
	},
	[305] = {
		[1] = 361,
		[2] = 'Lair of the Korlach',
		[3] = 'westkorlachc',
	},
	[306] = {
		[1] = 362,
		[2] = 'The Undershore',
		[3] = 'eastkorlach',
	},
	[307] = {
		[1] = 363,
		[2] = 'Snarlstone Dens',
		[3] = 'eastkorlacha',
	},
	[308] = {
		[1] = 364,
		[2] = 'Shadowspine',
		[3] = 'shadowspine',
	},
	[309] = {
		[1] = 365,
		[2] = 'Corathus Creep',
		[3] = 'corathus',
	},
	[310] = {
		[1] = 366,
		[2] = 'Sporali Caverns',
		[3] = 'corathusa',
	},
	[311] = {
		[1] = 367,
		[2] = 'Corathus Lair',
		[3] = 'corathusb',
	},
	[312] = {
		[1] = 368,
		[2] = 'Shadowed Grove',
		[3] = 'nektulosa',
	},
	[313] = {
		[1] = 369,
		[2] = 'Arcstone, Isle of Spirits',
		[3] = 'arcstone',
	},
	[314] = {
		[1] = 370,
		[2] = 'Relic, the Artifact City',
		[3] = 'relic',
	},
	[315] = {
		[1] = 371,
		[2] = 'Skylance',
		[3] = 'skylance',
	},
	[316] = {
		[1] = 372,
		[2] = 'The Devastation',
		[3] = 'devastation',
	},
	[317] = {
		[1] = 373,
		[2] = 'The Seething Wall',
		[3] = 'devastationa',
	},
	[318] = {
		[1] = 374,
		[2] = 'Sverag, Stronghold of Rage',
		[3] = 'rage',
	},
	[319] = {
		[1] = 375,
		[2] = 'Razorthorn, Tower of Sullon Zek',
		[3] = 'ragea',
	},
	[320] = {
		[1] = 376,
		[2] = 'Ruins of Takish-Hiz',
		[3] = 'takishruins',
	},
	[321] = {
		[1] = 377,
		[2] = 'The Root of Ro',
		[3] = 'takishruinsa',
	},
	[322] = {
		[1] = 378,
		[2] = 'The Elddar Forest',
		[3] = 'elddar',
	},
	[323] = {
		[1] = 379,
		[2] = 'Tunare\'s Shrine',
		[3] = 'elddara',
	},
	[324] = {
		[1] = 380,
		[2] = 'Theater of Blood',
		[3] = 'theater',
	},
	[325] = {
		[1] = 381,
		[2] = 'Deathknell, Tower of Dissonance',
		[3] = 'theatera',
	},
	[326] = {
		[1] = 382,
		[2] = 'East Freeport',
		[3] = 'freeporteast',
	},
	[327] = {
		[1] = 383,
		[2] = 'West Freeport',
		[3] = 'freeportwest',
	},
	[328] = {
		[1] = 384,
		[2] = 'Freeport Sewers',
		[3] = 'freeportsewers',
	},
	[329] = {
		[1] = 385,
		[2] = 'Academy of Arcane Sciences',
		[3] = 'freeportacademy',
	},
	[330] = {
		[1] = 386,
		[2] = 'Temple of Marr',
		[3] = 'freeporttemple',
	},
	[331] = {
		[1] = 387,
		[2] = 'Freeport Militia House',
		[3] = 'freeportmilitia',
	},
	[332] = {
		[1] = 388,
		[2] = 'Arena',
		[3] = 'freeportarena',
	},
	[333] = {
		[1] = 389,
		[2] = 'City Hall',
		[3] = 'freeportcityhall',
	},
	[334] = {
		[1] = 390,
		[2] = 'Theater',
		[3] = 'freeporttheater',
	},
	[335] = {
		[1] = 391,
		[2] = 'Hall of Truth',
		[3] = 'freeporthall',
	},
	[336] = {
		[1] = 392,
		[2] = 'North Desert of Ro',
		[3] = 'northro',
	},
	[337] = {
		[1] = 393,
		[2] = 'South Desert of Ro',
		[3] = 'southro',
	},
	[338] = {
		[1] = 394,
		[2] = 'Crescent Reach',
		[3] = 'crescent',
	},
	[339] = {
		[1] = 395,
		[2] = 'Blightfire Moors',
		[3] = 'moors',
	},
	[340] = {
		[1] = 396,
		[2] = 'Stone Hive',
		[3] = 'stonehive',
	},
	[341] = {
		[1] = 397,
		[2] = 'Goru`kar Mesa',
		[3] = 'mesa',
	},
	[342] = {
		[1] = 398,
		[2] = 'Blackfeather Roost',
		[3] = 'roost',
	},
	[343] = {
		[1] = 399,
		[2] = 'The Steppes',
		[3] = 'steppes',
	},
	[344] = {
		[1] = 400,
		[2] = 'Icefall Glacier',
		[3] = 'icefall',
	},
	[345] = {
		[1] = 401,
		[2] = 'Valdeholm',
		[3] = 'valdeholm',
	},
	[346] = {
		[1] = 402,
		[2] = 'Frostcrypt, Throne of the Shade King',
		[3] = 'frostcrypt',
	},
	[347] = {
		[1] = 403,
		[2] = 'Sunderock Springs',
		[3] = 'sunderock',
	},
	[348] = {
		[1] = 404,
		[2] = 'Vergalid Mines',
		[3] = 'vergalid',
	},
	[349] = {
		[1] = 405,
		[2] = 'Direwind Cliffs',
		[3] = 'direwind',
	},
	[350] = {
		[1] = 406,
		[2] = 'Ashengate, Reliquary of the Scale',
		[3] = 'ashengate',
	},
	[351] = {
		[1] = 407,
		[2] = 'Highpass Hold',
		[3] = 'highpasshold',
	},
	[352] = {
		[1] = 408,
		[2] = 'The Commonlands',
		[3] = 'commonlands',
	},
	[353] = {
		[1] = 409,
		[2] = 'The Ocean of Tears',
		[3] = 'oceanoftears',
	},
	[354] = {
		[1] = 413,
		[2] = 'Innothule Swamp',
		[3] = 'innothuleb',
	},
	[355] = {
		[1] = 414,
		[2] = 'Toxxulia Forest',
		[3] = 'toxxulia',
	},
	[356] = {
		[1] = 415,
		[2] = 'Misty Thicket',
		[3] = 'mistythicket',
	},
	[357] = {
		[1] = 416,
		[2] = 'Katta Castrum',
		[3] = 'kattacastrum',
	},
	[358] = {
		[1] = 417,
		[2] = 'Thalassius, the Coral Keep',
		[3] = 'thalassius',
	},
	[359] = {
		[1] = 418,
		[2] = 'Jewel of Atiiki',
		[3] = 'atiiki',
	},
	[360] = {
		[1] = 419,
		[2] = 'Zhisza, the Shissar Sanctuary',
		[3] = 'zhisza',
	},
	[361] = {
		[1] = 420,
		[2] = 'Silyssar, New Chelsith',
		[3] = 'silyssar',
	},
	[362] = {
		[1] = 421,
		[2] = 'Solteris, the Throne of Ro',
		[3] = 'solteris',
	},
	[363] = {
		[1] = 422,
		[2] = 'Barren Coast',
		[3] = 'barren',
	},
	[364] = {
		[1] = 423,
		[2] = 'The Buried Sea',
		[3] = 'buriedsea',
	},
	[365] = {
		[1] = 424,
		[2] = 'Jardel\'s Hook',
		[3] = 'jardelshook',
	},
	[366] = {
		[1] = 425,
		[2] = 'Monkey Rock',
		[3] = 'monkeyrock',
	},
	[367] = {
		[1] = 426,
		[2] = 'Suncrest Isle',
		[3] = 'suncrest',
	},
	[368] = {
		[1] = 427,
		[2] = 'Deadbone Reef',
		[3] = 'deadbone',
	},
	[369] = {
		[1] = 428,
		[2] = 'Blacksail Folly',
		[3] = 'blacksail',
	},
	[370] = {
		[1] = 429,
		[2] = 'Maiden\'s Grave',
		[3] = 'maidensgrave',
	},
	[371] = {
		[1] = 430,
		[2] = 'Redfeather Isle',
		[3] = 'redfeather',
	},
	[372] = {
		[1] = 431,
		[2] = 'The Open Sea',
		[3] = 'shipmvp',
	},
	[373] = {
		[1] = 432,
		[2] = 'The Open Sea',
		[3] = 'shipmvu',
	},
	[374] = {
		[1] = 433,
		[2] = 'The Open Sea',
		[3] = 'shippvu',
	},
	[375] = {
		[1] = 434,
		[2] = 'The Open Sea',
		[3] = 'shipuvu',
	},
	[376] = {
		[1] = 435,
		[2] = 'The Open Sea',
		[3] = 'shipmvm',
	},
	[377] = {
		[1] = 436,
		[2] = 'Fortress Mechanotus',
		[3] = 'mechanotus',
	},
	[378] = {
		[1] = 437,
		[2] = 'Meldrath\'s Majestic Mansion',
		[3] = 'mansion',
	},
	[379] = {
		[1] = 438,
		[2] = 'The Steam Factory',
		[3] = 'steamfactory',
	},
	[380] = {
		[1] = 439,
		[2] = 'S.H.I.P. Workshop',
		[3] = 'shipworkshop',
	},
	[381] = {
		[1] = 440,
		[2] = 'Gyrospire Beza',
		[3] = 'gyrospireb',
	},
	[382] = {
		[1] = 441,
		[2] = 'Gyrospire Zeka',
		[3] = 'gyrospirez',
	},
	[383] = {
		[1] = 442,
		[2] = 'Dragonscale Hills',
		[3] = 'dragonscale',
	},
	[384] = {
		[1] = 443,
		[2] = 'Loping Plains',
		[3] = 'lopingplains',
	},
	[385] = {
		[1] = 444,
		[2] = 'Hills of Shade',
		[3] = 'hillsofshade',
	},
	[386] = {
		[1] = 445,
		[2] = 'Bloodmoon Keep',
		[3] = 'bloodmoon',
	},
	[387] = {
		[1] = 446,
		[2] = 'Crystallos, Lair of the Awakened',
		[3] = 'crystallos',
	},
	[388] = {
		[1] = 447,
		[2] = 'The Mechamatic Guardian',
		[3] = 'guardian',
	},
	[389] = {
		[1] = 448,
		[2] = 'The Steamfont Mountains',
		[3] = 'steamfontmts',
	},
	[390] = {
		[1] = 449,
		[2] = 'Crypt of Shade',
		[3] = 'cryptofshade',
	},
	[391] = {
		[1] = 450,
		[2] = 'Tinmizer\'s Wunderwerks',
		[3] = 'dragonscalea',
	},
	[392] = {
		[1] = 451,
		[2] = 'Deepscar\'s Den',
		[3] = 'dragonscaleb',
	},
	[393] = {
		[1] = 452,
		[2] = 'Field of Scale',
		[3] = 'oldfieldofbone',
	},
	[394] = {
		[1] = 453,
		[2] = 'Kaesora Library',
		[3] = 'oldkaesoraa',
	},
	[395] = {
		[1] = 454,
		[2] = 'Kaesora Hatchery',
		[3] = 'oldkaesorab',
	},
	[396] = {
		[1] = 455,
		[2] = 'Kurn\'s Tower',
		[3] = 'oldkurn',
	},
	[397] = {
		[1] = 456,
		[2] = 'Bloody Kithicor',
		[3] = 'oldkithicor',
	},
	[398] = {
		[1] = 457,
		[2] = 'Old Commonlands',
		[3] = 'oldcommons',
	},
	[399] = {
		[1] = 459,
		[2] = 'The Void',
		[3] = 'thevoida',
	},
	[400] = {
		[1] = 460,
		[2] = 'The Void',
		[3] = 'thevoidb',
	},
	[401] = {
		[1] = 461,
		[2] = 'The Void',
		[3] = 'thevoidc',
	},
	[402] = {
		[1] = 462,
		[2] = 'The Void',
		[3] = 'thevoidd',
	},
	[403] = {
		[1] = 463,
		[2] = 'The Void',
		[3] = 'thevoide',
	},
	[404] = {
		[1] = 464,
		[2] = 'The Void',
		[3] = 'thevoidf',
	},
	[405] = {
		[1] = 465,
		[2] = 'The Void',
		[3] = 'thevoidg',
	},
	[406] = {
		[1] = 466,
		[2] = 'Oceangreen Hills',
		[3] = 'oceangreenhills',
	},
	[407] = {
		[1] = 467,
		[2] = 'Oceangreen Village',
		[3] = 'oceangreenvillage',
	},
	[408] = {
		[1] = 468,
		[2] = 'Blackburrow',
		[3] = 'oldblackburrow',
	},
	[409] = {
		[1] = 469,
		[2] = 'Temple of Bertoxxulous',
		[3] = 'bertoxtemple',
	},
	[410] = {
		[1] = 470,
		[2] = 'Korafax, Home of the Riders',
		[3] = 'discord',
	},
	[411] = {
		[1] = 471,
		[2] = 'Citadel of the Worldslayer',
		[3] = 'discordtower',
	},
	[412] = {
		[1] = 472,
		[2] = 'Old Bloodfields',
		[3] = 'oldbloodfield',
	},
	[413] = {
		[1] = 473,
		[2] = 'Precipice of War',
		[3] = 'precipiceofwar',
	},
	[414] = {
		[1] = 474,
		[2] = 'City of Dranik',
		[3] = 'olddranik',
	},
	[415] = {
		[1] = 475,
		[2] = 'Toskirakk',
		[3] = 'toskirakk',
	},
	[416] = {
		[1] = 476,
		[2] = 'Korascian Warrens',
		[3] = 'korascian',
	},
	[417] = {
		[1] = 477,
		[2] = 'Rathe Council Chamber',
		[3] = 'rathechamber',
	},
	[418] = {
		[1] = 478,
		[2] = 'Field of Scale',
		[3] = 'oldfieldofboneb',
	},
	[419] = {
		[1] = 480,
		[2] = 'Brell\'s Rest',
		[3] = 'brellsrest',
	},
	[420] = {
		[1] = 481,
		[2] = 'Fungal Forest',
		[3] = 'fungalforest',
	},
	[421] = {
		[1] = 482,
		[2] = 'The Underquarry',
		[3] = 'underquarry',
	},
	[422] = {
		[1] = 483,
		[2] = 'The Cooling Chamber',
		[3] = 'coolingchamber',
	},
	[423] = {
		[1] = 484,
		[2] = 'Kernagir, the Shining City',
		[3] = 'shiningcity',
	},
	[424] = {
		[1] = 485,
		[2] = 'Arthicrex',
		[3] = 'arthicrex',
	},
	[425] = {
		[1] = 486,
		[2] = 'The Foundation',
		[3] = 'foundation',
	},
	[426] = {
		[1] = 487,
		[2] = 'Lichen Creep',
		[3] = 'lichencreep',
	},
	[427] = {
		[1] = 488,
		[2] = 'Pellucid Grotto',
		[3] = 'pellucid',
	},
	[428] = {
		[1] = 489,
		[2] = 'Volska\'s Husk',
		[3] = 'stonesnake',
	},
	[429] = {
		[1] = 490,
		[2] = 'Brell\'s Temple',
		[3] = 'brellstemple',
	},
	[430] = {
		[1] = 491,
		[2] = 'The Convorteum',
		[3] = 'convorteum',
	},
	[431] = {
		[1] = 492,
		[2] = 'Brell\'s Arena',
		[3] = 'brellsarena',
	},
	[432] = {
		[1] = 493,
		[2] = 'Wedding Chapel',
		[3] = 'weddingchapel',
	},
	[433] = {
		[1] = 494,
		[2] = 'Wedding Chapel',
		[3] = 'weddingchapeldark',
	},
	[434] = {
		[1] = 495,
		[2] = 'Lair of the Fallen',
		[3] = 'dragoncrypt',
	},
	[435] = {
		[1] = 700,
		[2] = 'The Feerrott',
		[3] = 'feerrott2',
	},
	[436] = {
		[1] = 701,
		[2] = 'House of Thule',
		[3] = 'thulehouse1',
	},
	[437] = {
		[1] = 702,
		[2] = 'House of Thule, Upper Floors',
		[3] = 'thulehouse2',
	},
	[438] = {
		[1] = 703,
		[2] = 'The Grounds',
		[3] = 'housegarden',
	},
	[439] = {
		[1] = 704,
		[2] = 'The Library',
		[3] = 'thulelibrary',
	},
	[440] = {
		[1] = 705,
		[2] = 'The Well',
		[3] = 'well',
	},
	[441] = {
		[1] = 706,
		[2] = 'Erudin Burning',
		[3] = 'fallen',
	},
	[442] = {
		[1] = 707,
		[2] = 'Morell\'s Castle',
		[3] = 'morellcastle',
	},
	[443] = {
		[1] = 708,
		[2] = 'Sanctum Somnium',
		[3] = 'somnium',
	},
	[444] = {
		[1] = 709,
		[2] = 'Al\'Kabor\'s Nightmare',
		[3] = 'alkabormare',
	},
	[445] = {
		[1] = 710,
		[2] = 'Miragul\'s Nightmare',
		[3] = 'miragulmare',
	},
	[446] = {
		[1] = 711,
		[2] = 'Fear Itself',
		[3] = 'thuledream',
	},
	[447] = {
		[1] = 712,
		[2] = 'Sunrise Hills',
		[3] = 'neighborhood',
	},
	[448] = {
		[1] = 713,
		[2] = 'Miragul\'s Phylactery',
		[3] = 'phylactery',
	},
	[449] = {
		[1] = 714,
		[2] = 'Three Room House Interior',
		[3] = 'phinterior3a1',
	},
	[450] = {
		[1] = 715,
		[2] = 'One Room House Interior',
		[3] = 'phinterior1a1',
	},
	[451] = {
		[1] = 716,
		[2] = 'Three Room House Interior',
		[3] = 'phinterior3a2',
	},
	[452] = {
		[1] = 717,
		[2] = 'Three Room House Interior',
		[3] = 'phinterior3a3',
	},
	[453] = {
		[1] = 718,
		[2] = 'One Room House Interior',
		[3] = 'phinterior1a2',
	},
	[454] = {
		[1] = 719,
		[2] = 'One Room House Interior',
		[3] = 'phinterior1a3',
	},
	[455] = {
		[1] = 720,
		[2] = 'One Room House Interior',
		[3] = 'phinterior1b1',
	},
	[456] = {
		[1] = 723,
		[2] = 'Hermit\'s Hideaway Interior',
		[3] = 'phinterior1d1',
	},
	[457] = {
		[1] = 724,
		[2] = 'Argath, Bastion of Illdaera',
		[3] = 'argath',
	},
	[458] = {
		[1] = 725,
		[2] = 'Valley of Lunanyn',
		[3] = 'arelis',
	},
	[459] = {
		[1] = 726,
		[2] = 'Sarith, City of Tides',
		[3] = 'sarithcity',
	},
	[460] = {
		[1] = 727,
		[2] = 'Rubak Oseka, Temple of the Sea',
		[3] = 'rubak',
	},
	[461] = {
		[1] = 728,
		[2] = 'Beasts\' Domain',
		[3] = 'beastdomain',
	},
	[462] = {
		[1] = 729,
		[2] = 'The Resplendent Temple',
		[3] = 'resplendent',
	},
	[463] = {
		[1] = 730,
		[2] = 'Pillars of Alra',
		[3] = 'pillarsalra',
	},
	[464] = {
		[1] = 731,
		[2] = 'Windsong Sanctuary',
		[3] = 'windsong',
	},
	[465] = {
		[1] = 732,
		[2] = 'Erillion, City of Bronze',
		[3] = 'cityofbronze',
	},
	[466] = {
		[1] = 733,
		[2] = 'Sepulcher of Order',
		[3] = 'sepulcher',
	},
	[467] = {
		[1] = 734,
		[2] = 'Sepulcher East',
		[3] = 'eastsepulcher',
	},
	[468] = {
		[1] = 735,
		[2] = 'Sepulcher West',
		[3] = 'westsepulcher',
	},
	[469] = {
		[1] = 736,
		[2] = 'Shadowed Mount',
		[3] = 'shadowedmount',
	},
	[470] = {
		[1] = 737,
		[2] = 'Palatial Guild Hall',
		[3] = 'guildhalllrg',
	},
	[471] = {
		[1] = 738,
		[2] = 'Grand Guild Hall',
		[3] = 'guildhallsml',
	},
	[472] = {
		[1] = 739,
		[2] = 'One Bedroom House Interior',
		[3] = 'plhogrinteriors1a1',
	},
	[473] = {
		[1] = 740,
		[2] = 'One Bedroom House Interior',
		[3] = 'plhogrinteriors1a2',
	},
	[474] = {
		[1] = 741,
		[2] = 'Three Bedroom House Interior',
		[3] = 'plhogrinteriors3a1',
	},
	[475] = {
		[1] = 742,
		[2] = 'Three Bedroom House Interior',
		[3] = 'plhogrinteriors3a2',
	},
	[476] = {
		[1] = 743,
		[2] = 'Three Bedroom House Interior',
		[3] = 'plhogrinteriors3b1',
	},
	[477] = {
		[1] = 744,
		[2] = 'Three Bedroom House Interior',
		[3] = 'plhogrinteriors3b2',
	},
	[478] = {
		[1] = 745,
		[2] = 'One Bedroom House Interior',
		[3] = 'plhdkeinteriors1a1',
	},
	[479] = {
		[1] = 746,
		[2] = 'One Bedroom House Interior',
		[3] = 'plhdkeinteriors1a2',
	},
	[480] = {
		[1] = 747,
		[2] = 'One Bedroom House Interior',
		[3] = 'plhdkeinteriors1a3',
	},
	[481] = {
		[1] = 748,
		[2] = 'Three Bedroom House Interior',
		[3] = 'plhdkeinteriors3a1',
	},
	[482] = {
		[1] = 749,
		[2] = 'Three Bedroom House Interior',
		[3] = 'plhdkeinteriors3a2',
	},
	[483] = {
		[1] = 750,
		[2] = 'Three Bedroom House Interior',
		[3] = 'plhdkeinteriors3a3',
	},
	[484] = {
		[1] = 751,
		[2] = 'Modest Guild Hall',
		[3] = 'guildhall3',
	},
	[485] = {
		[1] = 752,
		[2] = 'Shard\'s Landing',
		[3] = 'shardslanding',
	},
	[486] = {
		[1] = 753,
		[2] = 'Valley of King Xorbb',
		[3] = 'xorbb',
	},
	[487] = {
		[1] = 754,
		[2] = 'Kael Drakkel: The King\'s Madness',
		[3] = 'kaelshard',
	},
	[488] = {
		[1] = 755,
		[2] = 'East Wastes: Zeixshi-Kar\'s Awakening',
		[3] = 'eastwastesshard',
	},
	[489] = {
		[1] = 756,
		[2] = 'The Crystal Caverns: Fragment of Fear',
		[3] = 'crystalshard',
	},
	[490] = {
		[1] = 757,
		[2] = 'The Breeding Grounds',
		[3] = 'breedinggrounds',
	},
	[491] = {
		[1] = 758,
		[2] = 'Evantil, the Vile Oak',
		[3] = 'eviltree',
	},
	[492] = {
		[1] = 759,
		[2] = 'Grelleth\'s Palace, the Chateau of Filth',
		[3] = 'grelleth',
	},
	[493] = {
		[1] = 760,
		[2] = 'Chapterhouse of the Fallen',
		[3] = 'chapterhouse',
	},
	[494] = {
		[1] = 763,
		[2] = 'Chelsith Reborn',
		[3] = 'chelsithreborn',
	},
	[495] = {
		[1] = 764,
		[2] = 'Plane of Shadow',
		[3] = 'poshadow',
	},
	[496] = {
		[1] = 765,
		[2] = 'Heart of Fear: The Threshold',
		[3] = 'heartoffear',
	},
	[497] = {
		[1] = 766,
		[2] = 'Evantil\'s Abode',
		[3] = 'phinteriortree',
	},
	[498] = {
		[1] = 768,
		[2] = 'Heart of Fear: The Rebirth',
		[3] = 'heartoffearb',
	},
	[499] = {
		[1] = 769,
		[2] = 'Heart of Fear: The Epicenter',
		[3] = 'heartoffearc',
	},
	[500] = {
		[1] = 770,
		[2] = 'Bixie Warfront',
		[3] = 'bixiewarfront',
	},
	[501] = {
		[1] = 771,
		[2] = 'The Dead Hills',
		[3] = 'deadhills',
	},
	[502] = {
		[1] = 772,
		[2] = 'Ethernere Tainted West Karana',
		[3] = 'ethernere',
	},
	[503] = {
		[1] = 773,
		[2] = 'The Void',
		[3] = 'thevoidh',
	},
	[504] = {
		[1] = 774,
		[2] = 'Bixie Hive',
		[3] = 'plhbixieint',
	},
	[505] = {
		[1] = 775,
		[2] = 'Tower of Rot',
		[3] = 'towerofrot',
	},
	[506] = {
		[1] = 776,
		[2] = 'Argin-Hiz',
		[3] = 'arginhiz',
	},
	[507] = {
		[1] = 777,
		[2] = 'Sul Vius: Demiplane of Life',
		[3] = 'exalted',
	},
	[508] = {
		[1] = 778,
		[2] = 'Arx Mentis',
		[3] = 'arxmentis',
	},
	[509] = {
		[1] = 779,
		[2] = 'Brother Island',
		[3] = 'brotherisland',
	},
	[510] = {
		[1] = 780,
		[2] = 'Katta Castrum: Deluge',
		[3] = 'kattacastrumb',
	},
	[511] = {
		[1] = 781,
		[2] = 'Combine Dredge',
		[3] = 'dredge',
	},
	[512] = {
		[1] = 782,
		[2] = 'Caverns of Endless Song',
		[3] = 'endlesscaverns',
	},
	[513] = {
		[1] = 783,
		[2] = 'Thuliasaur Island',
		[3] = 'thuliasaur',
	},
	[514] = {
		[1] = 784,
		[2] = 'Degmar, the Lost Castle',
		[3] = 'degmar',
	},
	[515] = {
		[1] = 785,
		[2] = 'Tempest Temple',
		[3] = 'tempesttemple',
	},
	[516] = {
		[1] = 786,
		[2] = 'The Wayward Lady',
		[3] = 'plhpirateshipint',
	},
	[517] = {
		[1] = 787,
		[2] = 'Gnome Memorial Mountain',
		[3] = 'gnomemtn',
	},
	[518] = {
		[1] = 788,
		[2] = 'The Temple of Droga',
		[3] = 'drogab',
	},
	[519] = {
		[1] = 789,
		[2] = 'Sathir\'s Tomb',
		[3] = 'charasisb',
	},
	[520] = {
		[1] = 790,
		[2] = 'The Scorched Woods',
		[3] = 'scorchedwoods',
	},
	[521] = {
		[1] = 791,
		[2] = 'Frontier Mountains',
		[3] = 'frontiermtnsb',
	},
	[522] = {
		[1] = 792,
		[2] = 'Gorowyn',
		[3] = 'gorowyn',
	},
	[523] = {
		[1] = 793,
		[2] = 'Gates of Kor-Sha',
		[3] = 'korshaext',
	},
	[524] = {
		[1] = 794,
		[2] = 'Lceanium',
		[3] = 'lceanium',
	},
	[525] = {
		[1] = 795,
		[2] = 'Crypt of Sul',
		[3] = 'cosul',
	},
	[526] = {
		[1] = 796,
		[2] = 'Ruins of Lxanvom',
		[3] = 'codecayb',
	},
	[527] = {
		[1] = 797,
		[2] = 'Sul Vius: Demiplane of Decay',
		[3] = 'exaltedb',
	},
	[528] = {
		[1] = 798,
		[2] = 'The Plane of Health',
		[3] = 'pohealth',
	},
	[529] = {
		[1] = 799,
		[2] = 'Kor-Sha Laboratory',
		[3] = 'korshaint',
	},
	[530] = {
		[1] = 800,
		[2] = 'Chardok',
		[3] = 'chardoktwo',
	},
	[531] = {
		[1] = 813,
		[2] = 'Howling Stones',
		[3] = 'charasistwo',
	},
	[532] = {
		[1] = 814,
		[2] = 'The Skyfire Mountains',
		[3] = 'skyfiretwo',
	},
	[533] = {
		[1] = 815,
		[2] = 'The Overthere',
		[3] = 'overtheretwo',
	},
	[534] = {
		[1] = 816,
		[2] = 'Veeshan\'s Peak',
		[3] = 'veeshantwo',
	},
	[535] = {
		[1] = 817,
		[2] = 'Plane of Smoke',
		[3] = 'trialsofsmoke',
	},
	[536] = {
		[1] = 818,
		[2] = 'Stratos: Zephyr\'s Flight',
		[3] = 'stratos',
	},
	[537] = {
		[1] = 819,
		[2] = 'Aalishai: Palace of Embers',
		[3] = 'aalishai',
	},
	[538] = {
		[1] = 820,
		[2] = 'Empyr: Realms of Ash',
		[3] = 'empyr',
	},
	[539] = {
		[1] = 821,
		[2] = 'Esianti: Palace of the Winds',
		[3] = 'esianti',
	},
	[540] = {
		[1] = 822,
		[2] = 'Mearatas: The Stone Demesne',
		[3] = 'mearatas',
	},
	[541] = {
		[1] = 823,
		[2] = 'Chamber of Tears',
		[3] = 'chamberoftears',
	},
	[542] = {
		[1] = 824,
		[2] = 'The Eastern Wastes',
		[3] = 'eastwastestwo',
	},
	[543] = {
		[1] = 825,
		[2] = 'The Tower of Frozen Shadow',
		[3] = 'frozenshadowtwo',
	},
	[544] = {
		[1] = 826,
		[2] = 'The Ry`Gorr Mines',
		[3] = 'crystaltwoa',
	},
	[545] = {
		[1] = 827,
		[2] = 'The Great Divide',
		[3] = 'greatdividetwo',
	},
	[546] = {
		[1] = 828,
		[2] = 'Velketor\'s Labyrinth',
		[3] = 'velketortwo',
	},
	[547] = {
		[1] = 829,
		[2] = 'Kael Drakkel',
		[3] = 'kaeltwo',
	},
	[548] = {
		[1] = 830,
		[2] = 'Crystal Caverns',
		[3] = 'crystaltwob',
	},
	[549] = {
		[1] = 831,
		[2] = 'The Sleeper\'s Tomb',
		[3] = 'sleepertwo',
	},
	[550] = {
		[1] = 832,
		[2] = 'Dragon Necropolis',
		[3] = 'necropolistwo',
	},
	[551] = {
		[1] = 833,
		[2] = 'Cobalt Scar',
		[3] = 'cobaltscartwo',
	},
	[552] = {
		[1] = 834,
		[2] = 'The Western Wastes',
		[3] = 'westwastestwo',
	},
	[553] = {
		[1] = 835,
		[2] = 'Skyshrine',
		[3] = 'skyshrinetwo',
	},
	[554] = {
		[1] = 836,
		[2] = 'The Temple of Veeshan',
		[3] = 'templeveeshantwo',
	},
	[555] = {
		[1] = 843,
		[2] = 'Maiden\'s Eye',
		[3] = 'maidentwo',
	},
	[556] = {
		[1] = 844,
		[2] = 'Umbral Plains',
		[3] = 'umbraltwo',
	},
	[557] = {
		[1] = 845,
		[2] = 'Ka Vethan',
		[3] = 'akhevatwo',
	},
	[558] = {
		[1] = 846,
		[2] = 'Vex Thal',
		[3] = 'vexthaltwo',
	},
	[559] = {
		[1] = 847,
		[2] = 'Shadow Valley',
		[3] = 'shadowvalley',
	},
	[560] = {
		[1] = 848,
		[2] = 'Basilica of Adumbration',
		[3] = 'basilica',
	},
	[561] = {
		[1] = 849,
		[2] = 'Bloodfalls',
		[3] = 'bloodfalls',
	},
	[562] = {
		[1] = 850,
		[2] = 'Coterie Chambers',
		[3] = 'maidenhouseint',
	},
	[563] = {
		[1] = 851,
		[2] = 'Ruins of Shadowhaven',
		[3] = 'shadowhaventwo',
	},
	[564] = {
		[1] = 852,
		[2] = 'Shar Vahl, Divided',
		[3] = 'sharvahltwo',
	},
	[565] = {
		[1] = 853,
		[2] = 'Paludal Depths',
		[3] = 'paludaltwo',
	},
	[566] = {
		[1] = 854,
		[2] = 'Shadeweaver\'s Tangl',
		[3] = 'shadeweavertwo',
	},
	[567] = {
		[1] = 855,
		[2] = 'Darklight Caverns',
		[3] = 'darklightcaverns',
	},
	[568] = {
		[1] = 856,
		[2] = 'Deepshade',
		[3] = 'deepshade',
	},
	[569] = {
		[1] = 857,
		[2] = 'Firefall Pass',
		[3] = 'firefallpass',
	},
	[570] = {
		[1] = 858,
		[2] = 'Hollowshade Moor',
		[3] = 'hollowshadetwo',
	},
	[571] = {
		[1] = 996,
		[2] = 'The Pit of Rathpher',
		[3] = 'arttest',
	},
	[572] = {
		[1] = 998,
		[2] = 'The Forgotten Halls',
		[3] = 'fhalls',
	},
}
