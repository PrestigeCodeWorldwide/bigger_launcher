#![allow(non_snake_case, unused_variables, unused_mut, unused_imports)]

use derive_more::Display;
use futures::future::err;
use log::{debug, error, info, warn};

use serde::{Deserialize, Serialize};
use simplelog::*;
use std::collections::HashMap;
use std::ops::Deref;
use std::process::id;
use std::sync::Arc;
use std::time::Duration;
use std::{clone, collections::HashSet};
use tokio::io::{AsyncBufReadExt, AsyncReadExt, AsyncWriteExt, WriteHalf};
use tokio::net::{TcpListener, TcpStream};
use tokio::sync::{mpsc, Mutex, MutexGuard};
use tokio::time::timeout;
use uuid::Uuid;
type AnyResult = anyhow::Result<()>;
use protocol::*;

pub const ADDR: &str = "0.0.0.0:8080";

#[tokio::main]
async fn main() -> AnyResult {
    let log_config = ConfigBuilder::new()
        .set_location_level(LevelFilter::Error)
        .set_time_level(LevelFilter::Error)
        .build();

    TermLogger::init(
        LevelFilter::Info,
        log_config,
        TerminalMode::Mixed,
        ColorChoice::Always,
    )?;
    let listener = TcpListener::bind(&ADDR).await?;
    let server = Arc::new(Mutex::new(Server {
        clients: HashMap::new(),
        writers: HashMap::new(),
        rooms: HashMap::new(),
    }));

    //let mut clientStreams: HashMap<ClientId, Arc<Mutex<TcpStream>>> = HashMap::new();

    info!("Listening on {}", &ADDR);

    loop {
        let (mut stream, _) = listener.accept().await?;
        info!("Received connection attempt from client");

        let server = Arc::clone(&server);

        let (reader, mut writer) = tokio::io::split(stream);

        // Spawn task for each client connection
        tokio::spawn(async move {
            let (mut tx, mut rx) = mpsc::unbounded_channel();
            let clientId = ClientId::new();

            {
                let mut server = server.lock().await;
                server
                    .clients
                    .insert(clientId.clone(), Client::new(clientId.clone(), tx.clone()));

                // write client ID back
                info!("Writing client ID {}", clientId.0.to_string());

                // Create a ClientConnectApproved instance
                let client_connect_approved =
                    ServerOperation::ClientConnectApproved(clientId.clone());

                // Serialize it to a JSON string
                let message = serde_json::to_string(&client_connect_approved).unwrap();

                // Add a newline character at the end
                let message_with_newline = format!("{}\n", message);

                // Write the serialized message to the client
                writer
                    .write_all(message_with_newline.as_bytes())
                    .await
                    .unwrap();
                writer.flush().await.unwrap(); // Add this line

                // stash the writer to use later
                server.writers.insert(clientId.clone(), writer);
            }

            // Spawn a task to listen for messages to send to the client
            let server_locked = Arc::clone(&server);
            let client_id_clone = clientId.clone();

            // Create a channel for sending dead client IDs
            let (dead_client_sender, mut dead_client_receiver) = tokio::sync::mpsc::channel(100);
            let server_locked_clone = Arc::clone(&server_locked);

            // Thread that writes incoming messages to client
            tokio::spawn(async move {
                // Wait for incoming message
                while let Some(message) = rx.recv().await {
                    // lock server mutex
                    let mut server = server_locked.lock().await;
                    // obtain writer access
                    if let Some(writer) = server.writers.get_mut(&client_id_clone) {
                        // Send actual TCP message
                        if let Err(e) = writer.write_all(message.as_bytes()).await {
                            error!(
                                "Failed to write message to client {}: {}",
                                clientId.clone().0,
                                e
                            );
                            // Send dead client ID to the removal task
                            if let Err(e) = dead_client_sender.send(client_id_clone).await {
                                error!("Failed to send dead client ID: {}", e);
                            }
                        }
                    }
                }
            });

            // Spawn a task for removing dead clients
            tokio::spawn(async move {
                while let Some(dead_client_id) = dead_client_receiver.recv().await {
                    let mut server = server_locked_clone.lock().await;
                    server.writers.remove(&dead_client_id);
                }
            });

            let mut buf = vec![];
            let mut reader = tokio::io::BufReader::new(reader);

            loop {
                buf.clear();
                let _ = reader.read_until(b'\n', &mut buf).await;

                info!(
                    "Deserializing from string: {}",
                    String::from_utf8_lossy(&buf)
                );
                let json_message = String::from_utf8_lossy(&buf)
                    .trim()
                    .trim_end_matches('\n')
                    .to_string();
                info!("JSON Message is: {}", &json_message);
                let message: Result<ClientMessage, _> = serde_json::from_str(&json_message);
                match message {
                    Ok(client_message) => match client_message.clientOperation {
                        ClientOperation::Message {
                            room,
                            channel,
                            message,
                        } => {
                            // We need to send this client message out to every single stream in all the tokio spawns

                            // Clone the message here
                            info!(
                                "Received client message: {} to room: {} and channel: {} from id: {}",
                                &message, &room, &channel, &client_message.clientId.unwrap_or(ClientId(Uuid::nil())).0
                            );
                            // We need to send this client message out to every single stream in all the tokio spawns
                            let mut server_guard = server.lock().await;
                            let responseMsg = format!("{} RESPONSE", message.clone());
                            let mut dead_clients = Vec::new();

                            if let Some(clients_in_room) = server_guard.rooms.get(&room) {
                                for client_id in clients_in_room {
                                    if let Some(client) = server_guard.clients.get(client_id) {
                                        if let Err(e) = client.tx.send(responseMsg.clone()) {
                                            error!(
                                                "Failed to send message to client {}: {}",
                                                client_id, e
                                            );
                                            // Queue dead client for removal
                                            dead_clients.push(*client_id);
                                        } else {
                                            info!("Sent message to client: {}", client_id);
                                        }
                                    }
                                }
                            }

                            // Remove dead clients
                            for client_id in dead_clients {
                                server_guard.clients.remove(&client_id);
                            }
                        }
                        ClientOperation::Disconnect => {
                            info!("The client has terminated the connection.");
                            break;
                        }
                        ClientOperation::ConnectAttempt => {
                            info!("In ClientConnectAttempt");

                            let tx_clone = tx.clone();
                            {
                                let mut server = server.lock().await;
                                server.clients.insert(
                                    clientId.clone(),
                                    Client::new(clientId.clone(), tx_clone),
                                );
                            }

                            // send client its new ID back
                            let server_operation =
                                ServerOperation::ClientConnectApproved(clientId.clone());
                            let operation_json = match serde_json::to_string(&server_operation) {
                                Ok(str) => str,
                                Err(err) => {
                                    error!(
                                        "Error occurred when serializing server operation: {}",
                                        err
                                    );
                                    continue;
                                }
                            };

                            info!("Writing to client stream");
                            // Write to the client's stream within the server lock scope
                            let mut server = server.lock().await;
                            if let Some(writer) = server.writers.get_mut(&clientId) {
                                if let Err(e) = writer.write_all(operation_json.as_bytes()).await {
                                    error!("Failed to write to client {}: {}", clientId, e);
                                } else {
                                    info!("Sent client response");
                                }
                            } else {
                                error!("Writer for client ID not found");
                            }
                        }
                        ClientOperation::RoomJoin(room) => {
                            info!("Client {} joining room {}", clientId, room);
                            let mut server = server.lock().await;
                            server
                                .rooms
                                .entry(room.clone())
                                .or_default()
                                .insert(clientId);
                            info!("Client {} joined room {}", clientId, room);
                        }
                        ClientOperation::RoomLeave(room) => {
                            info!("Client {} leaving room {}", clientId, room);
                            let mut server = server.lock().await;
                            if let Some(clients_in_room) = server.rooms.get_mut(&room) {
                                clients_in_room.remove(&clientId);
                                info!("Client {} left room {}", clientId, room);
                            }
                        }
                    },
                    Err(err) => {
                        warn!("Failed to parse the message: {}", err);
                        break;
                    }
                }
            }
        });
    }
}
